 $(document).ready(function(){
	jQuery('#header').raindrops(
	{	color:'#61C2F2',
		canvasHeight:150, 
		waveLength: 100,
	 	rippleSpeed: 0.05, 
		density: 0.04});
});
 
